#CSS Layout - Warmup

### Mockup
![mockup](./mockups/nat-geo-layout-mockup.png)

### Setup

```sh
cd ~/TIY/warmups

```